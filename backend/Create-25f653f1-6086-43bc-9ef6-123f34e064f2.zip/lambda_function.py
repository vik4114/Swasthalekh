import json
import time

import hashlib
import datetime
import boto3
dynamodb = boto3.resource('dynamodb')


def lambda_handler(event, context):
    
    timestamp = str(datetime.date.today())

    table = dynamodb.Table('users')
    
    
    hashed = event['password']
    password= hashlib.sha256(str.encode(hashed)).hexdigest()

    item = {
        
        'name': event['name'],
        
        'email': event['email'],
        'phone': event['phone'],
        'dob': event['dob'],
        'password': password,
        'createdAt': timestamp,
    }
    

    table.put_item(Item=item)
    
    
  
    response = {
        "statusCode": 200,
        "body": "User created successfully"
    }

    return response