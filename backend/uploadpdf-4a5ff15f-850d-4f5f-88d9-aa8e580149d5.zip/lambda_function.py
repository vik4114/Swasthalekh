import json
import boto3
import base64

def lambda_handler(event, context):
   s3 = boto3.client('s3')
   bucket = "mainstorage-swastha"
   key = event['name']

   URL=s3.generate_presigned_url("put_object",Params={"Bucket":bucket,"Key":key})
   return{
       "statusCode":200,
       
       "body":URL
       
   }