import os
import json
import boto3
dynamodb = boto3.resource('dynamodb')


def lambda_handler(event, context):
    table = dynamodb.Table('form')

    
    result = table.scan()
    history=result['Items']
    dname=[]
    date=[]
    pname=[]
    data1=event['query'].lower()
    
    
      
    for l in history:
        if(l['problem'].find(data1)!= -1 and l['phone']==event['phone']):
            dname.append(l['dname'])
            date.append(l['date'])
            pname.append(l['pname'])
                
    
    
    
    send={"dname":dname,
        "date":date,
        "pname":pname
    }
    
    
    response = {
        "statusCode": 200,
        "body": send
    }

    return response