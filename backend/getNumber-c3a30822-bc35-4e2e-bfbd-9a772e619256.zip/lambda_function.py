import os
import json
import boto3
dynamodb = boto3.resource('dynamodb')


def lambda_handler(event, context):
    table = dynamodb.Table('form')

   
    result = table.scan()
    history=result['Items']
    
    data1=event['number'].lower()
    
    
    for l in history:
        if(l['pname'].find(data1)!= -1):
            phonee=l['phone']
                
    
    
    
    
    

    response = {
        "statusCode": 200,
        "body": phonee
    }

    return response