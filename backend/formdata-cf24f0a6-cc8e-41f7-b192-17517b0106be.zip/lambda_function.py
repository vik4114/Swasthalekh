import json
import time

import hashlib
import datetime
import boto3
dynamodb = boto3.resource('dynamodb')


def lambda_handler(event, context):
    
    timestamp = str(datetime.date.today())

    table = dynamodb.Table('form')
    
    
    

    item = {
        
        'timestam': event['pname'],
        'phone': event['phone'],
        'dname': event['dname'].lower(),
        'prescription': event['prescription'].lower(),
        'problem': event['problem'].lower(),
        'date': event['date'].lower(),
        'pname': event['pname'],
    }
    

    table.put_item(Item=item)
    
    
    response = {
        "statusCode": 200,
        "body": "User created successfully"
    }

    return response