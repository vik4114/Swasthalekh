import json
import hashlib
import boto3
dynamodb = boto3.resource('dynamodb')


def lambda_handler(event, context):
    table = dynamodb.Table('users')
    
    hashed = event['password']
    password= hashlib.sha256(str.encode(hashed)).hexdigest()


    result = table.get_item(
        Key={
            'email': event['email']
        }
    )
    
    if(result['Item']['password']==password):
        response = {
        "statusCode": 200,
        "result": "true",
        "name" : result['Item']['name'],
        "phone" : result['Item']['phone'],
        }
    else:
        response = {
        "statusCode": 200,
        "result": "false",
        }
    

    return response